'use strict';

module.exports = {
  async up (queryInterface, Sequelize) {
    /**
     * Add seed commands here.
     *
     * Example:
     */
    await queryInterface.bulkInsert('Configurations', [{
      nomeSistema: 'Whats Talk',
      numeroSuporte: '555192919891',
      codigoCor: '#0039e6',
      logo: null, // Para BLOB, você pode precisar inserir um buffer ou null
      mensagemWhatsApp: 'Mensagem de WhatsApp padrão',
      mensagemEmail: 'Mensagem de e-mail padrão',
      mensagemRedefinicaoSenha: 'Olá,\n\nVocê solicitou a redefinição da sua senha para a sua conta. Para continuar com o processo de redefinição, por favor, utilize o token de segurança abaixo:\n\nToken de Redefinição: {tokenSenha}\n\nSe você não solicitou a redefinição da senha, por favor ignore este e-mail ou entre em contato conosco se você acredita que isso foi um erro.\n\nAgradecemos pela sua atenção.\n\nAtenciosamente',
      createdAt: new Date(),
      updatedAt: new Date()
    }], {});
  },

  async down (queryInterface, Sequelize) {
    /**
     * Add commands to revert seed here.
     *
     * Example:
     */
    await queryInterface.bulkDelete('Configurations', null, {});
  }
};